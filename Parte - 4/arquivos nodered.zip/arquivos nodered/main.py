from Irrigar import Irrigar

irrigar = Irrigar()

irrigar.iniciar()

